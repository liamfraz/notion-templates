# AI Side Hustle Tracker -- Lite

> A free starter template for tracking your AI-powered income streams. Want the full version with monthly revenue tracking, project management, expense logging, and monthly review workflows? Upgrade to the Premium version.

---

## `// INCOME STREAMS`

Track every AI-powered income stream in one place. Know where your money comes from.

### How to Use

Add a row for each income stream with:
- What it is and what type (Freelance, Content, Product, etc.)
- Which platform you sell on
- Monthly revenue and hours per week
- Current status (Active, Scaling, Paused, Planning)

### Income Streams

| Name | Type | Platform | Monthly Revenue ($) | Status | Effort (hrs/week) |
|------|------|----------|-------------------|--------|-------------------|
| Claude Code Consulting | Freelance AI Dev | Upwork | 8,000 | Scaling | 20 |
| AI Newsletter | AI Content | Substack | 1,450 | Active | 6 |
| n8n Automation Builds | Automation Agency | Own Website | 5,500 | Scaling | 15 |

> **Tip:** Convert this table to a Notion database for filtering and sorting. Select the table, then click "Turn into database."

### Quick Revenue Health Check

```
For each stream, calculate your effective hourly rate:
Monthly Revenue / (Hours per week x 4.3) = $/hour

Under $30/hour = Red flag. Automate, outsource, or kill it.
$30-$70/hour  = Acceptable. Look for ways to improve.
Over $70/hour = Strong. Protect this stream and scale it.
```

---

## `// TOOL COSTS`

Know what your AI tools cost and whether they're worth it.

### Your Tools

| Tool | Monthly Cost ($) | Category | ROI Rating | Status |
|------|-----------------|----------|-----------|--------|
| Claude Pro | 20 | AI Model | Essential | Active |
| ChatGPT Plus | 20 | AI Model | High ROI | Active |
| Midjourney | 30 | Design | High ROI | Active |
| n8n Cloud | 24 | Automation | Essential | Active |
| Canva Pro | 13 | Design | High ROI | Active |

### ROI Quick Check

```
Essential  = Business stops without it. Keep.
High ROI   = Clearly pays for itself. Keep.
Medium ROI = Useful but not critical. Review quarterly.
Low ROI    = Barely used. Cancel within 30 days.

Rule of thumb: Total tool costs should be under 10% of revenue.
```

---

## `// GOALS`

Set targets and track progress. Keep yourself accountable.

### Your Goals

| Goal | Target | Current | Status | Deadline |
|------|--------|---------|--------|----------|
| Hit $10K/mo total revenue | $10,000 | $8,500 | On Track | June 2026 |
| Launch Advanced Course | 1 course | 0 | Not Started | May 2026 |
| 5000 Newsletter Subscribers | 5,000 | 2,650 | Behind | June 2026 |

### Weekly Review (10 minutes)

```
Every Sunday evening:
- Update the "Current" column for each goal
- Flag anything that slipped to "Behind"
- Write one specific action for this week
```

---

## `// WHAT'S IN THE FULL VERSION?`

The Premium AI Side Hustle Tracker includes everything above plus:

- **Revenue Dashboard** -- monthly snapshot with trends and alerts
- **Monthly Revenue Tracking** -- per-stream revenue, expenses, and profit over time
- **Project Pipeline** -- track launches, improvements, and milestones by stream
- **Expense Logger** -- categorised business expenses with tax deduction tracking
- **Monthly Review Workflow** -- structured 30-minute end-of-month review checklist
- **6 pre-built CSV databases** with realistic sample data
- **Australian tax context** -- deduction categories and ATO references
- **Setup guide** with step-by-step database configuration

[Get AI Side Hustle Tracker Premium ->](YOUR_GUMROAD_LINK_HERE)

---

*Built for the AI side hustle era. Track it, optimise it, scale it.*
