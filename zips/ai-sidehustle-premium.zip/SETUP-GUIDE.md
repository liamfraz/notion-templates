# AI Side Hustle Tracker -- Setup Guide

Get the full dashboard running in your Notion workspace in about 45 minutes.

---

## Step 1: Import the Main Template

1. Open Notion and navigate to your workspace sidebar
2. Click **Import** (at the bottom of the sidebar)
3. Select **Markdown** and upload `ai-sidehustle-main.md`
4. Notion will create a new page with all the sections

Alternatively, create a new page and paste the markdown content directly.

---

## Step 2: Create Databases from CSVs

For each CSV file in the `databases/` folder, create a Notion database:

### Income Streams Database

1. In Notion, create a new **Full-page database**
2. Name it `Income Streams`
3. Click the `...` menu at the top right of the database
4. Select **Merge with CSV** and upload `databases/income-streams.csv`
5. Set column types:
   - Name: `Title`
   - Type: `Select` (options: Freelance AI Dev, Prompt Engineering, AI Content, AI Tutoring, AI SaaS, Automation Agency, AI Art/Design)
   - Platform: `Select` (options: Upwork, Fiverr, Gumroad, YouTube, Substack, Etsy, Own Website, Udemy, Amazon KDP)
   - Monthly Revenue ($): `Number` (format: US Dollar)
   - Status: `Select` (options: Active, Paused, Planning, Scaling)
   - Effort (hrs/week): `Number`
   - Started: `Date`
   - Category: `Select` (options: Product, Service, Content, Course)
   - Growth Rate: `Text`

### Monthly Revenue Database

1. Create a new **Full-page database** named `Monthly Revenue`
2. Merge with `databases/monthly-revenue.csv`
3. Set column types:
   - Month: `Date` (set to first of month)
   - Stream: `Select` (match your Income Streams names)
   - Revenue ($): `Number` (format: US Dollar)
   - Expenses ($): `Number` (format: US Dollar)
   - Net Profit ($): `Number` (format: US Dollar)
   - Hours Spent: `Number`
   - Hourly Rate ($): `Number` (format: US Dollar)
   - Growth vs Prior Month: `Text`
   - Notes: `Text`

### Tool Costs Database

1. Create a new **Full-page database** named `Tool Costs`
2. Merge with `databases/tool-costs.csv`
3. Set column types:
   - Tool: `Title`
   - Monthly Cost ($): `Number` (format: US Dollar)
   - Category: `Select` (options: AI Model, Design, Automation, Productivity, Video, Audio)
   - Used For: `Text`
   - Streams Using It: `Text`
   - ROI Rating: `Select` (options: Essential, High ROI, Medium ROI, Low ROI, Under Review)
   - Status: `Select` (options: Active, Under Review, Cancelled)
   - Notes: `Text`

### Projects Database

1. Create a new **Full-page database** named `Projects`
2. Merge with `databases/projects.csv`
3. Set column types:
   - Name: `Title`
   - Stream: `Select` (match your Income Streams names)
   - Status: `Select` (options: Active, In Progress, Planning, On Hold, Complete)
   - Priority: `Select` (options: High, Medium, Low)
   - Start Date: `Date`
   - Target Revenue ($/mo): `Number` (format: US Dollar)
   - Current Revenue ($/mo): `Number` (format: US Dollar)
   - Next Milestone: `Text`
   - Category: `Select` (options: Product, Service, Content, Course)

### Expenses Database

1. Create a new **Full-page database** named `Expenses`
2. Merge with `databases/expenses.csv`
3. Set column types:
   - Date: `Date`
   - Category: `Select` (options: Software, Marketing, Education, Hardware, Outsourcing, Hosting)
   - Description: `Title`
   - Amount ($): `Number` (format: US Dollar)
   - Stream: `Select` (match your Income Streams names)
   - Tax Deductible: `Checkbox`
   - Payment Method: `Select` (options: Credit Card, PayPal, Bank Transfer)
   - Receipt: `Text`

### Goals Database

1. Create a new **Full-page database** named `Goals`
2. Merge with `databases/goals.csv`
3. Set column types:
   - Goal: `Title`
   - Target: `Text`
   - Current: `Text`
   - Status: `Select` (options: On Track, Behind, Achieved, Not Started)
   - Deadline: `Date`
   - Stream: `Select` (match your Income Streams names, plus "All Streams")
   - Priority: `Select` (options: High, Medium, Low)
   - Notes: `Text`

---

## Step 3: Customise Your Income Streams

This is the most important step. Replace the sample data with your actual hustles.

1. Open the **Income Streams** database
2. Delete all sample rows
3. Add your real income streams:
   - Be honest about monthly revenue (use last month's actual number)
   - Track effort accurately (set a timer for one week if you're not sure)
   - Set the right status -- don't mark something "Active" if you haven't worked on it in 3 weeks

If you only have 1-2 streams, that's fine. The template scales. You'll add more as you grow.

---

## Step 4: Set Up Monthly Tracking

The Monthly Revenue database is where the real insights live.

### First Month Setup

1. Add one row per income stream for the current month
2. Fill in revenue, expenses, and hours spent
3. The hourly rate will tell you immediately which streams are worth your time

### Monthly Routine (30 minutes, last day of the month)

```
1. Open each platform dashboard and note final revenue numbers
2. Add rows to Monthly Revenue for each active stream
3. Log any missing expenses
4. Update Goals progress
5. Review the Monthly Review checklist in the main template
```

### Setting a Calendar Reminder

Block 30 minutes on the last working day of each month. Title it "Side Hustle Monthly Review" and link to your Notion template page.

---

## Step 5: Configure Tool Cost Monitoring

1. Open the **Tool Costs** database
2. Replace sample tools with your actual subscriptions
3. For each tool, honestly assess the ROI rating:
   - Would your business stop if you cancelled it? -> Essential
   - Does it clearly generate more than it costs? -> High ROI
   - Nice to have but you could survive without it? -> Medium ROI
   - You forgot you were paying for it? -> Low ROI (cancel it now)

### Quarterly Tool Audit

Every 3 months, review every tool:
- Check if you actually used it in the last 30 days
- Verify the pricing hasn't changed
- Look for free alternatives that have improved
- Cancel anything rated Low ROI that hasn't improved

---

## Step 6: Set Up Database Relations

Notion relations link databases together for more powerful tracking.

### Income Streams <-> Monthly Revenue
1. Open the Monthly Revenue database
2. Add a new `Relation` property pointing to `Income Streams`
3. Name it "Stream Link"
4. This lets you click through from a monthly entry to see the full stream details

### Income Streams <-> Projects
1. Open the Projects database
2. Add a new `Relation` property pointing to `Income Streams`
3. Name it "Income Stream"
4. Track which projects feed which revenue streams

### Income Streams <-> Expenses
1. Open the Expenses database
2. Add a new `Relation` property pointing to `Income Streams`
3. Name it "Revenue Stream"
4. See all expenses tied to a specific hustle

### Income Streams <-> Goals
1. Open the Goals database
2. Add a new `Relation` property pointing to `Income Streams`
3. Name it "Related Stream"
4. Connect goals to the streams they're driving

### Relation Map

```
Income Streams (central hub)
  |-- Monthly Revenue (track earnings over time)
  |-- Projects (what you're building)
  |-- Expenses (what it costs)
  |-- Goals (where you're headed)

Tool Costs (standalone -- linked via text field "Streams Using It")
```

---

## Step 7: Create Linked Database Views

1. Go back to the main AI Side Hustle Tracker page
2. In each section that says "Create a linked database view here", type `/linked` and select **Create linked view of database**
3. Point each linked view to the appropriate database
4. Set up the recommended views listed in each section (filters, sorts, grouping)

### Recommended Dashboard Layout

For the Dashboard section at the top:
- Create a **Gallery view** of Income Streams showing Name, Revenue, and Status
- Create a **Board view** of Projects grouped by Status
- Create a **List view** of Goals filtered to Status != Achieved

---

## Tips

- **Start with Income Streams and Monthly Revenue.** These two databases give you 80% of the value. Add the others as you settle in.
- **Be brutally honest with numbers.** This template is for you, not for showing off on Twitter. Accurate data leads to better decisions.
- **Review weekly, decide monthly.** Quick 10-minute goal check on Sundays, full 30-minute review at month-end.
- **Kill underperformers.** If a stream has been under $30/hour for 3 months and isn't growing, pause it and redirect that time to your top earners.
- **Track time for one week.** If you don't know how many hours each stream takes, set a timer for one week. The numbers might surprise you.

---

*Questions? Feature requests? Reach out on X or open an issue on GitHub.*
