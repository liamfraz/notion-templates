# AI Side Hustle Tracker

> Track every income stream, tool cost, and growth goal across your AI-powered side hustles. Built for the multi-hustle era.

---

## `// QUICK START`

1. **Import this page** into your Notion workspace
2. **Create databases** from the CSV files in the `/databases` folder (see SETUP-GUIDE.md)
3. **Customise your income streams** -- replace the sample data with your actual hustles
4. **Set your first monthly review** -- block 30 minutes at month-end to review numbers

**Estimated setup time:** 45 minutes

---

## `// DASHBOARD`

Your bird's-eye view of every dollar coming in and going out. Pin this page to your sidebar.

### Revenue Snapshot (Update Monthly)

| Metric | This Month | Last Month | Trend |
|--------|-----------|-----------|-------|
| Total Revenue | $8,500 | $7,600 | Up |
| Total Expenses | $1,420 | $1,280 | Up |
| Net Profit | $7,080 | $6,320 | Up |
| Active Streams | 8 | 7 | Up |
| Avg Hourly Rate | $72.40 | $68.50 | Up |
| Tool Costs | $198 | $198 | Stable |

### Quick Actions

- [ ] Update this month's revenue for each stream
- [ ] Log any new expenses
- [ ] Check tool ROI -- cancel anything underperforming
- [ ] Review goals progress
- [ ] Plan next month's priorities

### Alerts

> **Goal Alert:** Newsletter subscriber growth slowed -- consider paid recommendations
> **Revenue Alert:** AI Thumbnail SaaS still at $0 -- MVP delayed, reassess timeline
> **Cost Alert:** ElevenLabs subscription under review -- low ROI, consider cancelling

---

## `// INCOME STREAMS`

Every AI-powered income stream in one place. The goal: know exactly where your money comes from and how much effort each stream takes.

### Stream Health Guide

| Status | Meaning | Action |
|--------|---------|--------|
| Active | Running and generating revenue | Maintain and optimise |
| Scaling | Actively investing to grow | Track growth rate weekly |
| Paused | Temporarily stopped | Review monthly -- restart or kill |
| Planning | Not yet launched | Set a launch date or drop it |

### Linked Database: Income Streams

> *Create a linked database view here pointing to the Income Streams database*
> Recommended views:
> - **All Active** -- filtered to Status = Active or Scaling, sorted by Monthly Revenue descending
> - **By Category** -- grouped by Category column (Product, Service, Content, Course)
> - **By Platform** -- grouped by Platform column
> - **Revenue Ranked** -- sorted by Monthly Revenue descending
> - **Effort vs Revenue** -- sorted by effective hourly rate (Revenue / Effort)

### Revenue per Hour Calculator

For each stream, calculate your effective hourly rate:

```
Monthly Revenue / (Effort hrs/week x 4.3) = $/hour

Example: $5,500 / (15 x 4.3) = $85.27/hour
```

Anything below $30/hour is a red flag. Either automate it, outsource it, or kill it.

### The 80/20 Rule for Side Hustles

```
Most people spread too thin. Focus on the streams that:
1. Generate the highest $/hour
2. Have the strongest growth rate
3. Build compounding assets (courses, templates, SaaS)
4. Require the least active time (passive income)

Kill or pause everything else. 3-4 focused streams beat 8 scattered ones.
```

---

## `// MONTHLY REVENUE`

Track revenue, expenses, and profit for each stream every month. This is where you spot trends.

### Linked Database: Monthly Revenue

> *Create a linked database view here pointing to the Monthly Revenue database*
> Recommended views:
> - **Current Month** -- filtered to current month, sorted by Revenue descending
> - **By Stream** -- grouped by Stream column
> - **Trend** -- sorted by Month, showing Revenue and Net Profit columns
> - **Hourly Rate** -- sorted by Hourly Rate descending

### Monthly Review Template

Copy this at the end of each month:

```
## [MONTH YEAR] Revenue Review

### Summary
Total Revenue: $[AMOUNT]
Total Expenses: $[AMOUNT]
Net Profit: $[AMOUNT]
Total Hours: [COUNT]
Blended Hourly Rate: $[AMOUNT]

### Top Performer
Stream: [NAME]
Revenue: $[AMOUNT]
Why: [EXPLANATION]

### Underperformer
Stream: [NAME]
Revenue: $[AMOUNT]
Action: [SCALE / PIVOT / KILL]

### Key Decisions
- [What to double down on]
- [What to cut or pause]
- [New streams to explore]
```

---

## `// TOOL COSTS`

Know exactly what your AI tools cost and whether they're earning their keep.

### Linked Database: Tool Costs

> *Create a linked database view here pointing to the Tool Costs database*
> Recommended views:
> - **All Active** -- filtered to Status = Active, sorted by Monthly Cost descending
> - **By Category** -- grouped by Category (AI Model, Design, Automation, etc.)
> - **ROI Review** -- filtered to ROI Rating = Low ROI or Under Review
> - **Monthly Total** -- showing sum of Monthly Cost column

### ROI Rating Guide

| Rating | Definition | Action |
|--------|-----------|--------|
| Essential | Business stops without it | Keep -- no questions asked |
| High ROI | Clearly pays for itself many times over | Keep and maximise usage |
| Medium ROI | Useful but not critical | Review quarterly -- could you use a free alternative? |
| Low ROI | Rarely used or marginal benefit | Cancel within 30 days unless usage increases |
| Under Review | Not enough data yet | Set a 60-day review date with clear success criteria |

### Monthly Tool Cost Budget

```
Rule of thumb: Tool costs should be under 10% of total revenue.

Current: $198/month tools vs ~$8,500/month revenue = 2.3% -- healthy

Warning thresholds:
  Under 5%  -- great, tools are well-leveraged
  5-10%     -- acceptable, review quarterly
  10-15%    -- getting heavy, audit for waste
  Over 15%  -- immediate review, cancel underperformers
```

---

## `// PROJECTS`

Track every project tied to your income streams -- launches, improvements, milestones.

### Linked Database: Projects

> *Create a linked database view here pointing to the Projects database*
> Recommended views:
> - **Active Work** -- filtered to Status = Active or In Progress, sorted by Priority
> - **By Stream** -- grouped by Stream column
> - **Pipeline** -- board view grouped by Status (Planning -> In Progress -> Active -> Complete)
> - **Revenue Gap** -- showing Target Revenue vs Current Revenue

### Project Prioritisation

Use this simple framework to decide what to work on:

```
PRIORITY MATRIX

High Impact + Low Effort  = DO FIRST  (quick wins)
High Impact + High Effort = SCHEDULE   (big bets)
Low Impact  + Low Effort  = DELEGATE   (if possible)
Low Impact  + High Effort = DROP       (time traps)
```

---

## `// EXPENSES`

Track every business expense for tax time and profit calculations.

### Linked Database: Expenses

> *Create a linked database view here pointing to the Expenses database*
> Recommended views:
> - **Recent** -- sorted by Date descending
> - **By Category** -- grouped by Category (Software, Marketing, Education, etc.)
> - **By Stream** -- grouped by Stream column
> - **Tax Deductible** -- filtered to Tax Deductible = Yes
> - **Monthly Total** -- sorted by Date, showing sum of Amount

### Tax Deduction Categories (Australia)

```
Commonly deductible for AI side hustles:
- Software subscriptions (AI tools, hosting, design tools)
- Marketing and advertising spend
- Education and training (courses, bootcamps)
- Hardware (laptop, tablet, monitor -- percentage of business use)
- Home office expenses (percentage of rent/mortgage, utilities)
- Outsourcing and contractor payments
- Domain names and hosting

Keep ALL receipts. Use the Receipt column to track file names.
Talk to your accountant about the $20K instant asset write-off threshold.
```

### Expense Logging Habit

```
Log expenses as they happen -- not at tax time.
Set a weekly reminder (Friday afternoon):
1. Check bank statement for business charges
2. Add any missing expenses to the database
3. Attach receipt files
4. Tag the income stream it belongs to
```

---

## `// GOALS`

Set targets, track progress, stay accountable.

### Linked Database: Goals

> *Create a linked database view here pointing to the Goals database*
> Recommended views:
> - **Active Goals** -- filtered to Status != Achieved, sorted by Priority
> - **By Stream** -- grouped by Stream column
> - **Behind Schedule** -- filtered to Status = Behind
> - **Achieved** -- filtered to Status = Achieved (celebrate wins)

### Goal-Setting Framework

```
Every goal needs:
1. A specific number (not "grow newsletter" but "reach 5000 subscribers")
2. A deadline (not "someday" but "by 30 June 2026")
3. A weekly check-in metric you can measure
4. An action plan (what you'll do this week to move closer)

Bad:  "Make more money from AI"
Good: "Hit $10,000/month total revenue across all streams by 30 June 2026"
```

### Weekly Goal Review (15 minutes)

```
Every Sunday evening:
- [ ] Update "Current" column for each active goal
- [ ] Mark any achieved goals
- [ ] Flag goals that slipped to "Behind"
- [ ] For behind goals: write one specific action for this week
- [ ] Remove or replace any goals you no longer care about
```

---

## `// MONTHLY REVIEW`

Block 30 minutes on the last day of each month. Go through this checklist.

### Monthly Review Checklist

```
REVENUE (10 min)
- [ ] Update Monthly Revenue database with final numbers
- [ ] Calculate net profit for each stream
- [ ] Identify top and bottom performers
- [ ] Decide: scale, maintain, or kill each stream

EXPENSES (5 min)
- [ ] Log any missing expenses
- [ ] Review tool subscriptions -- cancel unused ones
- [ ] Check total tool cost as % of revenue

GOALS (10 min)
- [ ] Update progress on all active goals
- [ ] Archive completed goals
- [ ] Set new goals for next month
- [ ] Identify the ONE thing that would move the needle most

PLANNING (5 min)
- [ ] What's the #1 priority for next month?
- [ ] Any new streams worth exploring?
- [ ] Any streams to pause or kill?
- [ ] Block time in calendar for high-priority work
```

---

## `// RESOURCES`

### Useful Links

- [Gumroad Creator Dashboard](https://gumroad.com/dashboard) -- digital product sales
- [Substack Dashboard](https://substack.com/dashboard) -- newsletter analytics
- [Udemy Instructor Dashboard](https://www.udemy.com/instructor/) -- course revenue
- [Etsy Shop Manager](https://www.etsy.com/your/shops/me/dashboard) -- print-on-demand sales
- [Upwork Reports](https://www.upwork.com/reports/) -- freelance earnings
- [ATO Business Portal](https://www.ato.gov.au/business/) -- Australian tax obligations

### Side Hustle Health Indicators

```
GREEN (healthy):
  Revenue growing month-over-month
  Hourly rate above $50
  Tool costs under 5% of revenue
  At least one passive income stream

YELLOW (watch):
  Revenue flat for 2+ months
  Hourly rate between $30-$50
  Tool costs between 5-10% of revenue
  All income requires active work

RED (fix now):
  Revenue declining
  Hourly rate below $30
  Tool costs above 10% of revenue
  Burning out from too many streams
```

---

*Built for the AI side hustle era. Track it, optimise it, scale it.*
*Version 1.0 | Last updated: March 2026*
